<?php

$email_to = "aa_taxation@hotmail.co.nz"; // your email address
$email_subject = "Send Us A Message"; // email subject line
$thankyou = "thankyou.htm"; // thank you page

// If you update the question on the form -
// you need to update the questions answer below
$antispam_answer = "25";

// Do not change this line
$base = "CgpGb3JtIHBvd2VyZWQgYnkgaHR0cHM6Ly93d3cuZnJlZWNvbnRhY3Rmb3JtLmNvbQ==";