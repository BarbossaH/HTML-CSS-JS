function gotoURL(url){
    window.location.assign(url);
}